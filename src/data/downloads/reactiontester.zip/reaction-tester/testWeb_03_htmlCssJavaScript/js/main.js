document.getElementById('buttonStyleText').addEventListener('click', function () {
    document.getElementById('title').style.backgroundColor = '#333';
    document.getElementById('title').style.color = 'yellow';
});