/* eslint-disable no-unused-vars */

function colorChange() {
    document.getElementById('green-list').style.color = 'green';
    document.getElementById('red-list').style.color = 'red';
    document.getElementById('blue-list').style.color = 'blue';
    document.getElementById('computer').innerHTML = 'now the language';
    document.getElementById('language-btn').style.display = 'block';
    document.getElementById('colours-btn').style.display = 'none';
}


function languageChange() {
    document.getElementById('green-list').innerHTML = 'grün';
    document.getElementById('red-list').innerHTML = 'rot';
    document.getElementById('blue-list').innerHTML = 'blau';
    document.getElementById('computer').innerHTML = 'completed';
    document.getElementById('restart').style.display = 'block';

}


