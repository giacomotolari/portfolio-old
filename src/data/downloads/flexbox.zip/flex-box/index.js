/* eslint-disable no-unused-vars */

function displayFlex() {
    document.getElementById('container').style.display = 'flex';
   
}
function flexDirectionRow() {
    document.getElementById('container').style.flexDirection = 'row';
   
}

function flexWrapWrapDeverse() {
    document.getElementById('container').style.flexDirection = 'row-reverse';
   
}

function FlexDirectionColumn() {
    document.getElementById('container').style.flexFlow = 'column';
   
}

function justifyContentCenter() {
    document.getElementById('container').style.justifyContent = 'center';
   
}
function justifyContentSpace() {
    document.getElementById('container').style.justifyContent = 'space-between';
}



// off buttons


function displayFlexOff() {
    document.getElementById('container').style.display = 'block';
   
}